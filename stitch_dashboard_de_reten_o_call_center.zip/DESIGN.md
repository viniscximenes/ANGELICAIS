---
name: Precision Analytics
colors:
  surface: '#fbf8fa'
  surface-dim: '#dcd9db'
  surface-bright: '#fbf8fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f4'
  surface-container: '#f0edef'
  surface-container-high: '#eae7e9'
  surface-container-highest: '#e4e2e3'
  on-surface: '#1b1b1d'
  on-surface-variant: '#45474c'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#111516'
  on-tertiary: '#ffffff'
  tertiary-container: '#26292b'
  on-tertiary-container: '#8d9092'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#e0e3e5'
  tertiary-fixed-dim: '#c4c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#fbf8fa'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e3'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  kpi-value:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 16px
  card-padding: 24px
---

## Brand & Style
The design system is anchored in **Professional Minimalism**, prioritizing clarity, data density without clutter, and an atmosphere of calm authority. Designed for call center retention specialists, the interface reduces cognitive load through a restrained aesthetic that emphasizes information hierarchy.

The visual language draws from **Corporate Modernism**, utilizing generous whitespace, a systematic grid, and subtle depth to organize complex analytical data. Every element serves a functional purpose, eschewing decorative flourishes for high-performance utility and a trustworthy, institutional feel.

## Colors
The palette is built on a foundation of "Professional Navy" and "Slate" to establish a neutral, focused environment. 

- **Primary (#1E293B):** Used for core navigation, primary headings, and high-emphasis actions.
- **Secondary (#64748B):** Used for supporting text, icons, and secondary interface elements.
- **Neutral/Surface (#F8FAFC):** The primary background color to ensure a clean, "airy" feel.
- **Functional Colors:** Success, Error, and Warning colors are used sparingly but vibrantly to highlight KPIs and critical status changes in retention metrics. 
- **Border/Divider:** Use #E2E8F0 for subtle structural separation.

## Typography
This design system utilizes **Inter** for its exceptional legibility in data-heavy environments. 

- **Hierarchy:** High-contrast weights distinguish between labels and values. Use `700` weight specifically for KPI values to ensure they are the first thing a user sees.
- **Micro-copy:** Use `label-md` for table headers and chart legends to maintain clarity at small sizes.
- **Spacing:** Tighten letter-spacing on larger headings (`display-lg`, `headline-lg`) to maintain a polished, "editorial" corporate look.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a max-width container for desktop viewing. 

- **Rhythm:** An 8px base unit governs all dimensions. 
- **The "Airy" Principle:** Use large 24px gutters and 40px page margins to prevent the dashboard from feeling claustrophobic. 
- **Grouping:** Related analytical cards should be grouped with 24px gaps; unrelated sections should use 48px or 64px vertical spacing.
- **Mobile Adaptation:** On mobile devices, the grid collapses to a single column, and margins reduce to 16px to maximize horizontal real estate for tables and charts.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** and **Ambient Shadows** rather than heavy borders.

- **Primary Surface:** The main background is `#F8FAFC`.
- **Raised Cards:** White (`#FFFFFF`) backgrounds with a very soft, diffused shadow: `0px 4px 6px -1px rgba(0, 0, 0, 0.05), 0px 2px 4px -2px rgba(0, 0, 0, 0.05)`.
- **Interactive Elements:** Buttons and hover states use a slightly more pronounced shadow to indicate clickability.
- **Overlays:** Modals and dropdowns use a "Medium" shadow to clearly separate the action layer from the data layer.

## Shapes
The shape language is **Soft and Precise**. 

- **Standard Elements:** Buttons, input fields, and cards utilize a `0.25rem` (4px) or `0.5rem` (8px) radius. This provides a modern touch while maintaining the professional, "squared-off" rigor expected in enterprise software.
- **Icons:** Use a 2px stroke weight with slightly rounded joins to match the typeface characteristics of Inter.

## Components
- **KPI Cards:** White background, 24px padding. Headline in `label-md` (Slate), value in `kpi-value` (Navy). Trend indicators (Success/Alert) should be placed immediately adjacent to the value.
- **Data Tables:** Use a "Ghost" style. No vertical borders. Horizontal rows separated by 1px `#F1F5F9`. Header background is subtly tinted `#F8FAFC`.
- **Buttons:** 
  - *Primary:* Solid `#1E293B` with White text.
  - *Secondary:* Outline `#E2E8F0` with `#475569` text.
- **Inputs:** 1px border `#D1D5DB`. On focus, use a 2px ring of `#3B82F6` with 20% opacity.
- **Modern Charts:** Use a palette of Navy, Slate, and Blue for primary data. Reserve Success Green and Alert Red strictly for performance status to avoid visual confusion.
- **Status Chips:** Low-saturation backgrounds with high-saturation text (e.g., light green background with dark green text) for subtle but clear categorization.